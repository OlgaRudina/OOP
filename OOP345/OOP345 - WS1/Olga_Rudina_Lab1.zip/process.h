#pragma once

	void process(char* string, std::ostream& os);